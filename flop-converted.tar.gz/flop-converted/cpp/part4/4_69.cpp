//файл part4\4_69.CPP
//Рис. 4.69a Kонструктор копирования,
//перегруженный оператор присваивания

#include <string.h>
#include "c:\cpp\subprog\\roll.h"
#include "c:\cpp\class\\gr_txt.h"
#include "c:\cpp\class\newtest.cpp"
typedef char *STRINGP;

class Name {
static int m;//номер обычного конструктора с арг.
static int n;//номер констр.копирования

public:
char *pP;

Name(int k=10){//обычный конструктор с арг.по умолчанию
m++;cout<<"\n обычный констр.№"<<m;
 pP=new char[k];//выделение памяти для массива
 newtest(pP);/*проверка выделения памяти*/ }

Name(const Name &ob)//конструктор копирования
{n++;cout<<"\nконстр.копир.№"<<n;
 pP=new char[strlen(ob.pP)+1];//выделение памяти 
 newtest(pP);//прoверка выделения памяти
 strcpy(pP,ob.pP); /*копирование*/ }

~Name(){cout<<" деструктор";delete []pP;}/*деструктор,
освобождение памяти массива*/

 Name &operator=(const Name &ob2)
//перегрузка присваивания
{if(&ob2 !=this)//проверка на самоприсваивание
 {delete []pP;//освобождение памяти 
  pP=new char[strlen(ob2.pP)+1];//выделение памяти
  newtest(pP); //прoверка выделения памяти
  strcpy(pP,ob2.pP);/*копирование*/ 
  cout<<"\n присваивание";}
  else {cout<<"\n самоприсваивание";pause(9);}
  return *this;   }

 friend Name operator+(Name,Name);//перегрузка сложения
 };  //конец объявления класса
    
int Name::m=0;//инициализация статических
int Name::n=0;//элементoв класса

Name operator+(Name ob1, Name ob2)//перегрузка сложения
{Name ob(strlen(ob1.pP)+strlen(ob2.pP)+1);//обычный конструктор
 strcpy(ob.pP,ob1.pP);
 strncat(ob.pP,ob2.pP,strlen(ob2.pP));
 return ob;}
    
void print(Name &ob){cout<<'\n'<<ob.pP;}//вывод массива

main(){STRINGP word1[]={" Michael"},
	       word2[]={" Smith"};
 Name ob1(strlen(*word1)+1),ob2(strlen(*word2)+1); 
 strcpy(ob1.pP,*word1);print(ob1);
 strcpy(ob2.pP,*word2);print(ob2);

 {Name ob3=ob1; // инициализация
 print(ob3);};cout<<"\n выход из блока";

 {Name ob4; ob4=ob2;//присваивание
  print(ob4);};cout<<"\n выход из блока";
  ob1=ob1;//попытка самоприсваивания

  print(ob1+ob2);//сложение

  cout<<endl<<" контрольный вывод";
 print(ob1);print(ob2); cout<<"\n конец задачи";
 return 0;}
